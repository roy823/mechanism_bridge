"""Molecular depictions and actual saved geometry/energy trajectories for the pilot.

No new electronic-structure evaluations, coordinate interpolation or TS bond-order
assignment. Dashed contacts are changes between endpoint Lewis graphs, not arrows.
"""
from collections import Counter
from pathlib import Path
import base64
import hashlib
import io
import json
import re
import numpy as np
from ase import Atoms
from ase.io import read, write
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors, rdDepictor
from rdkit.Chem.Draw import rdMolDraw2D
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from .event_graph import geometry_mol, graph_smiles, bond_orders
from .species_network import layout_species,project_species_network

ROOT=Path(__file__).resolve().parents[2]
COLORS={1:'#dbe3ef',6:'#475569',7:'#3478d4',8:'#e95058',15:'#e08b2e'}
NAMES={'CC=O':'乙醛','C=CO':'乙烯醇','C[N+](=O)[O-]':'硝基甲烷',
       'C=[N+]([O-])O':'aci-nitro 互变体','O=[NH+]C[O-]':'意外连接候选',
       'CC(N)=O':'乙酰胺','O=C1CCC1':'环丁酮','O=CC1CC1':'环收缩产物候选'}
NAMES.update({'CC(C)=O':'丙酮','CCC=O':'丙醛','C=C(C)O':'丙酮烯醇'})
NAMES.update({'O=CCO':'羟基乙醛','O/C=C\\O':'乙烯二醇',
    'O=C[C@H](O)CO':'甘油醛','O=C[C@@H](O)CO':'甘油醛',
    'O=C(CO)CO':'二羟基丙酮','CC(=O)CC(C)=O':'乙酰丙酮',
    'CC[N+](=O)[O-]':'硝基乙烷','OC1=CCC1':'环丁酮烯醇',
    'CC.[C-]#[O+]':'乙烷 + 一氧化碳',
    '[H]/[C-]=[O+]\\CC':'局部电荷中间体候选'})

NAMES.update({'C=O.O':'甲醛 + 水','OCO':'甲二醇','C=O.C=O':'两分子甲醛',
    'C=O.O=CCO':'甲醛 + 羟基乙醛','C=O.O/C=C/O':'甲醛 + 乙烯二醇',
    'C#[N+][N-]C.C=C':'腈亚胺 + 乙烯','CN1CCC=N1':'五元环加成产物',
    'C=C.C=[N+]=[C-]C':'偶极体 + 乙烯','CC1=NCCC1':'五元环加成产物',
    'COC(=O)CO':'羟基乙酸甲酯','C=CN(C)N=C':'开链加成产物',
    'O/C=C/OCO':'烯醇的羟甲基醚'})
NAMES.update({'C1CO1.N':'环氧乙烷 + 氨','[NH3+]CC[O-]':'2-氨基乙醇两性离子',
    'NCCO':'2-氨基乙醇','CC=O.N':'乙醛 + 氨','C=O.CN':'甲醛 + 甲胺',
    'O=CC(O)CO':'甘油醛','O=C[C@H](O)CO':'甘油醛','O=C[C@@H](O)CO':'甘油醛',
    'CN1CCC=N1':'[3+2] 环加成产物','C#[N+][N-]C.C=C':'腈亚胺 + 乙烯',
    'C=CN(C)N=C':'开链加成产物','O=CCC=O':'丙二醛'})


def depiction(mol, png=False):
    m=Chem.Mol(mol)
    for atom in m.GetAtoms(): atom.SetAtomMapNum(0)
    m=Chem.RemoveHs(m)
    rdDepictor.Compute2DCoords(m)
    drawer=(rdMolDraw2D.MolDraw2DCairo if png else rdMolDraw2D.MolDraw2DSVG)(460,200)
    options=drawer.drawOptions()
    options.bondLineWidth=2.5
    options.padding=.18
    drawer.DrawMolecule(m)
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def clean_svg(svg):
    return svg[svg.index('<svg'):]


def symbolic_graph_key(smiles):
    """Compare symbolic endpoints without inventing unspecified stereochemistry."""
    mol=Chem.MolFromSmiles(smiles)
    if mol is None:raise ValueError(f'Cannot parse symbolic endpoint: {smiles}')
    return Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False)


def entry(mol, coordinates):
    smiles=graph_smiles(mol)
    formulas=[rdMolDescriptors.CalcMolFormula(m) for m in Chem.GetMolFrags(mol,asMols=True)]
    return dict(smiles=smiles,name=NAMES.get(smiles,'已优化构型'),
        formula=' + '.join(formulas),total_formula=rdMolDescriptors.CalcMolFormula(mol),svg=clean_svg(depiction(mol)),
        positions=np.asarray(coordinates).tolist(),
        bonds=[dict(i=i,j=j,order=order) for (i,j),order in bond_orders(mol).items()])


def display_rotation(ts):
    centered=ts-ts.mean(0)
    _,_,vt=np.linalg.svd(centered)
    rotation=vt.T
    if np.linalg.det(rotation)<0: rotation[:,-1]*=-1
    return rotation


def load_events(run, network_paths=None, layout_network=True):
    events=[]
    networks=[]
    manifest_path=Path(run)/'manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}
    model=manifest.get('model','aimnet2-rxn')
    method_label={'aimnet2-2025':'AIMNet2-2025 member0 · B97-3c',
                  'aimnet2':'AIMNet2 member0 · ωB97M-D3',
                  'aimnet2-nse':'AIMNet2-NSE member0 · ωB97M-D3'}.get(model,'AIMNet2-rxn ensemble_0')
    paths=run.glob('*/*/network.json') if network_paths is None else [Path(p).resolve() for p in network_paths]
    for path in sorted(paths):
        n=json.loads(path.read_text(encoding='utf-8'))
        if n['status']=='running': raise ValueError('Only finished runs can be visualized')
        if n['status']!='completed':continue
        numbers=n['start']['atomic_numbers']
        symbols=Atoms(numbers=numbers).get_chemical_symbols()
        projection=project_species_network(n['nodes'],n['edges'],n['root_component_nodes'])
        physical_entries={}
        for node in n['nodes']:
            m=geometry_mol(numbers,node['positions_A'],0)
            physical_entries[node['id']]=dict(id=node['id'],**entry(m,node['positions_A']),
                energy=node['energy_eV']-n['nodes'][0]['energy_eV'])
        display_nodes=[]
        for species in projection['nodes']:
            representative=dict(physical_entries[species['representative_node']])
            representative.update(id=species['id'],conformer_count=len(species['physical_nodes']),
                                  physical_nodes=species['physical_nodes'])
            display_nodes.append(representative)
        network=dict(start=n['start']['id'],strategy=n['strategy'],nodes=display_nodes,edges=[],
                     root_nodes=projection['root_nodes'],physical_node_count=len(n['nodes']))
        projected_edges={edge['id']:edge for edge in projection['edges']}
        for edge in n['edges']:
            attempt=n['attempts'][edge['attempt']]
            folder=path.parent/f"attempt_{edge['attempt']:03d}"
            data=json.loads((folder/'result.json').read_text())
            # Prefer the actual endpoint corresponding to the proposing node on the left.
            left=edge['nodes'].index(attempt['source_node']) if attempt['source_node'] in edge['nodes'] else 0
            right=1-left
            endpoints=data['endpoints']
            ts=np.array(data['ts_positions_A'])
            rotation=display_rotation(ts)
            center=ts.mean(0)
            mols=[geometry_mol(numbers,e['positions_A'],0) for e in endpoints]
            endpoint_entries=[entry(m,e['positions_A']) for m,e in zip(mols,endpoints)]
            branches=[read(folder/f'descent_{sign}.traj',index=':') for sign in (-1,1)]
            frames=[]
            for a in branches[left][::-1]:
                frames.append(dict(positions=a.positions.tolist(),energy=float(a.calc.results['energy']),branch='left'))
            ts_index=len(frames)
            frames.append(dict(positions=ts.tolist(),energy=data['ts']['energy_eV'],branch='ts'))
            for a in branches[right]:
                frames.append(dict(positions=a.positions.tolist(),energy=float(a.calc.results['energy']),branch='right'))
            baseline=endpoints[left]['energy_eV']
            for frame in frames:
                frame['display_positions']=((np.array(frame['positions'])-center)@rotation).round(7).tolist()
                frame['relative_energy']=frame['energy']-baseline
            before,after=bond_orders(mols[left]),bond_orders(mols[right])
            changes=[dict(i=i,j=j,before=before.get((i,j),0),after=after.get((i,j),0))
                     for i,j in sorted(before.keys()|after.keys()) if before.get((i,j),0)!=after.get((i,j),0)]
            for c in changes:
                c['label']=f"{symbols[c['i']]}{c['i']+1}–{symbols[c['j']]}{c['j']+1}"
                c['distances']=[float(np.linalg.norm(np.array(f['positions'])[c['i']]-np.array(f['positions'])[c['j']])) for f in frames]
            pair=[endpoint_entries[left]['smiles'],endpoint_entries[right]['smiles']]
            proposal=attempt['proposal'].get('predicted_graph')
            source=n['nodes'][attempt['source_node']]['graph_smiles']
            matched=(sorted(map(symbolic_graph_key,pair))==
                     sorted(map(symbolic_graph_key,[source,proposal]))) if proposal else None
            eid=f"{n['start']['id']}_{n['strategy']}_{edge['id']}"
            physical_node_ids=[edge['nodes'][left],edge['nodes'][right]]
            event=dict(id=eid,start=n['start']['id'],strategy=n['strategy'],edge_id=edge['id'],
                node_ids=[projection['physical_to_species'][i] for i in physical_node_ids],
                physical_node_ids=physical_node_ids,symbols=symbols,numbers=numbers,
                left=endpoint_entries[left],right=endpoint_entries[right],frames=frames,ts_index=ts_index,
                changes=changes,ts_energy=data['ts']['energy_eV'],
                barrier_forward=endpoints[left]['barrier_eV'],barrier_reverse=endpoints[right]['barrier_eV'],
                imaginary_frequency=data['ts']['frequencies_cm-1'][0],
                matched_proposal=matched,predicted_graph=proposal,
                root_connected=set(edge['nodes'])<=set(n['root_component_nodes']),
                artifact=folder.relative_to(run).as_posix(),is_IRC=False,DFT_verified=False,
                evidence='MLIP_DESCENT',method_label=method_label,
                path_label='沿负模位移后的双侧 BFGS 下降，非 IRC',related_checks=[],
                source_result=(folder/'result.json').relative_to(ROOT).as_posix())
            events.append(event)
            projected=projected_edges[edge['id']]
            network['edges'].append(dict(id=eid,nodes=projected['nodes'],barriers=edge['barriers_eV'],
                physical_nodes=edge['nodes'],parallel_index=projected['parallel_index'],
                parallel_count=projected['parallel_count']))
        if layout_network:
            layout=layout_species(network['nodes'],network['edges'])
            for node in network['nodes']:node['layout']=layout[node['id']]
        networks.append(network)
    # Start with the clean, familiar chemical example, while exposing every saved edge.
    events.sort(key=lambda e:(e['start']!='MR_8342_1',e['strategy']!='arrows',not e['root_connected'],e['edge_id']))
    return events,networks


def draw_structure(ax, frame, event, bonds, transition=False):
    x=np.array(frame['display_positions'])
    changed={(c['i'],c['j']) for c in event['changes']}
    for b in bonds:
        i,j=b['i'],b['j']
        if transition and tuple(sorted((i,j))) in changed: continue
        mid=(x[i]+x[j])/2
        ax.plot(*np.stack([x[i],mid]).T,color=COLORS[event['numbers'][i]],lw=5,solid_capstyle='round')
        ax.plot(*np.stack([mid,x[j]]).T,color=COLORS[event['numbers'][j]],lw=5,solid_capstyle='round')
    if transition:
        for c in event['changes']:
            p=x[[c['i'],c['j']]]
            ax.plot(*p.T,ls='--',lw=2,color='#d39a28')
    phi=np.linspace(0,np.pi,16);theta=np.linspace(0,2*np.pi,22)
    for i,(z,p) in enumerate(zip(event['numbers'],x)):
        r=.19 if z==1 else .28
        xx=p[0]+r*np.outer(np.sin(phi),np.cos(theta))
        yy=p[1]+r*np.outer(np.sin(phi),np.sin(theta))
        zz=p[2]+r*np.outer(np.cos(phi),np.ones_like(theta))
        ax.plot_surface(xx,yy,zz,color=COLORS[z],linewidth=0,shade=True,antialiased=True)
        ax.text(p[0],p[1],p[2]+r+.12,f"{event['symbols'][i]}{i+1}",fontsize=9,ha='center',color='#21354b')
    extent=max(np.ptp(np.array(f['display_positions']),axis=0).max() for f in event['frames'])/2+.65
    for setter in (ax.set_xlim,ax.set_ylim,ax.set_zlim):setter(-extent,extent)
    ax.set_box_aspect((1,1,1),zoom=1.38);ax.view_init(elev=65,azim=-90);ax.set_axis_off()


def static_figure(event,out):
    font=Path('C:/Windows/Fonts/msyh.ttc')
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams['axes.unicode_minus']=False
    plt.rcParams['pdf.fonttype']=42
    fig=plt.figure(figsize=(14,10),layout='constrained',facecolor='#f6f8fc')
    grid=fig.add_gridspec(4,3,height_ratios=[1.0,2.0,1.2,.18])
    left,right=event['left'],event['right']
    formula_math='$'+re.sub(r'(\d+)',r'_{\1}',left['formula'])+'$'
    connectivity = '根连通' if event['root_connected'] else '未与初始盆地连通'
    fig.suptitle(f"[{connectivity}] {left['name']} → TS → {right['name']}   |   {formula_math}",fontsize=20,color='#152d48')
    for col,end,frame in [(0,left,event['frames'][0]),(2,right,event['frames'][-1])]:
        ax=fig.add_subplot(grid[0,col]);ax.axis('off')
        m=geometry_mol(event['numbers'],end['positions'],0)
        ax.imshow(plt.imread(io.BytesIO(depiction(m,png=True)),format='png'))
        formula_end='$'+re.sub(r'(\d+)',r'_{\1}',end['formula'])+'$'
        ax.set_title(f"{end['name']}  ·  {formula_end}",fontsize=13)
    ax=fig.add_subplot(grid[0,1]);ax.axis('off')
    ax.text(.5,.65,'→  TS  →',ha='center',fontsize=23,color='#b88724')
    ax.text(.5,.3,f"正向势垒 {event['barrier_forward']:.3f} eV\n逆向势垒 {event['barrier_reverse']:.3f} eV",ha='center',fontsize=12,linespacing=1.8)
    union={tuple(sorted((b['i'],b['j']))):b for b in left['bonds']+right['bonds']}
    for col,index,title,bonds,transition in [
        (0,0,'实际下降端点 A',left['bonds'],False),
        (1,event['ts_index'],'实际优化 TS · 一个虚频',list(union.values()),True),
        (2,len(event['frames'])-1,'实际下降端点 B',right['bonds'],False)]:
        ax=fig.add_subplot(grid[1,col],projection='3d',facecolor='#f6f8fc')
        draw_structure(ax,event['frames'][index],event,bonds,transition)
        ax.set_title(title,fontsize=12,color='#21354b')
    ax=fig.add_subplot(grid[2,:2])
    energies=[f['relative_energy'] for f in event['frames']]
    ax.plot(energies,color='#167d9a',lw=2)
    ax.scatter([event['ts_index']],[energies[event['ts_index']]],color='#d39a28',s=55,zorder=5)
    ax.axvline(event['ts_index'],ls='--',color='#d39a28',alpha=.5)
    ax.set(xlabel='保存的构型帧序号（左侧下降逆序 → TS → 右侧下降）',ylabel='相对端点 A 的势能 / eV')
    ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.15)
    ax=fig.add_subplot(grid[2,2]);ax.axis('off')
    changes=event['changes']
    text='关键原子对距离 / Å\n\n'
    for c in changes[:4]:
        d=c['distances']
        text+=f"{c['label']}:  {d[0]:.2f} → {d[event['ts_index']]:.2f} → {d[-1]:.2f}\n"
    text+=f"\nTS 虚频：{event['imaginary_frequency']:.1f} "+r'$\mathrm{cm}^{-1}$'
    ax.text(0,1,text,va='top',fontsize=10,linespacing=1.7)
    ax=fig.add_subplot(grid[3,:]);ax.axis('off')
    ax.text(0,.5,'坐标与能量来自实际 AIMNet2-rxn 计算；黄色虚线表示端点间变化的键。图示为双侧 BFGS 下降，非 IRC / 非动力学时间；独立 DFT 复核见对应报告。',fontsize=9,color='#58677d')
    stem='reaction_'+event['id']
    fig.savefig(out/(stem+'.png'),dpi=180)
    fig.savefig(out/(stem+'.pdf'))
    plt.close(fig)
    return stem


def render_visuals(run,network_paths=None,make_static=True):
    from .report_layout import molecular_document,prepare_shared_assets,relative_link,attach_checks
    run=Path(run).resolve()
    out=run/'molecules';out.mkdir(exist_ok=True)
    events,networks=load_events(run,network_paths)
    # Keep actual source geometries in downloadable XYZ, SDF and multi-frame XYZ.
    for event in events:
        eid=event['id']
        path=[]
        for f in event['frames']:
            atoms=Atoms(numbers=event['numbers'],positions=f['positions'])
            atoms.info['relative_energy_eV']=f['relative_energy']
            atoms.info['branch']=f['branch'];path.append(atoms)
        write(out/(eid+'_path.xyz'),path,format='extxyz')
        write(out/(eid+'_TS.xyz'),path[event['ts_index']],write_results=False)
        for side in ['left','right']:
            m=geometry_mol(event['numbers'],event[side]['positions'],0)
            (out/(eid+'_'+side+'.mol')).write_text(Chem.MolToMolBlock(m),encoding='utf-8')
        event['downloads']=dict(path=eid+'_path.xyz',ts=eid+'_TS.xyz',left=eid+'_left.mol',right=eid+'_right.mol')
    selected=[];seen=set()
    for e in events:
        pair=tuple(sorted([e['left']['smiles'],e['right']['smiles']]))
        if pair[0] != pair[1] and pair not in seen:
            seen.add(pair);selected.append(e)
    figures=[static_figure(e,out) for e in selected] if make_static else []
    prepare_shared_assets();attach_checks(events,out)
    stage=run.relative_to(ROOT/'reports').parts[0]
    payload=dict(events=events,networks=networks,figures=figures,
                 report_url=relative_link(ROOT/'reports'/stage/'index.html',out))
    rendered=molecular_document(payload,out)
    (out/'index.html').write_text(rendered,encoding='utf-8')
    provenance=dict(event_count=len(events),figures=figures,
        positions='Actual saved unmodified coordinates; display applies one common rigid rotation per event',
        energy='Saved trajectory energies and saved TS result; no new model calls',
        frames='Reversed left BFGS descent + saved TS + forward right BFGS descent; no interpolation',
        bond_display='Endpoint Lewis graphs; changing contacts dashed in TS/path, no TS bond-order claim',
        source_hashes={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in run.glob('*/*/attempt_*/result.json') if json.loads(p.read_text())['status']=='validated_descents'})
    (out/'provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    return dict(page=str(out/'index.html'),events=len(events),figures=figures)
